import 'package:flutter/material.dart';


class customeColor_ extends StatelessWidget {
  MaterialColor mycolor = MaterialColor(0xff00a685, <int, Color>{
    50: Color(0xff00a685),
    100: Color(0xff00a685),
    200: Color(0xff00a685),
    300: Color(0xff00a685),
    400: Color(0xff00a685),
    500: Color(0xff00a685),
    600: Color(0xff00a685),
    700: Color(0xff00a685),
    800: Color(0xff00a685),
    900: Color(0xff00a685),
  });

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
